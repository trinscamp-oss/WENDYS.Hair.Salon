New Client Booking!
Client Name: {{client_name}}
Email: {{client_email}}
Phone: {{client_phone}}
Date: {{booking_date}}
Time: {{booking_time}}
Service: {{service_style}}
Notes: {{notes}}